package org.tnsif.threadlifecycle;

public class Sender {

}
