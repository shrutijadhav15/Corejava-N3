package org.tnsif.stringdemo;

//program to demonstrate an object class
class Sample{
	
}
public class ObjectClassDemo {

	public static void main(String[] args) {
		Sample s = new Sample();
		System.out.println(s.getClass());
		System.out.println(s.hashCode());

	}

}
