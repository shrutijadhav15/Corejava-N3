package org.tnsif.stringdemo;

//String is a final class. It is immutable
//can't inherit final class

/*public class StringSubClass extends String{

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}*/
