package org.tnsif.wrapperclassdemo;

public class WrapperClassExample {

	public static void main(String[] args) {
		System.out.println("Welcome to TNSIF");
		
		int a = Integer.parseInt(args[1]);
		int b = Integer.parseInt(args[2]);
		int res = a+b;
		System.out.println(res);

	}

}
