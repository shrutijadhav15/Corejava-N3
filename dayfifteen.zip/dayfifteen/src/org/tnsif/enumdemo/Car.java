package org.tnsif.enumdemo;
//declaring enum constants
public enum Car {
	MARUTI,HONDA,TESLA,ARYA

}
